global.token = ['YOUR TOKEN BOT FROM BOTFATHER']
global.channelId = '@notifyjf_store'; // Ganti dengan channel mu dan masukan bot kedalam channel

global.creator = ['1234101835'] // USING USER ID
global.owner = ['1234101835'] // USING USER ID
global.botName = 'JF Store'
global.ownerName = 'JF Dev'

global.gold = 196350
global.platinum = 232050

global.poster= 'https://topup.j-f.cloud/assets/banner/banner.jpg'

// Mongodb
global.mongodb = "mongodb+srv://" // ganti dengan url database mongodb mu
global.database = "botdb" // Sesuaikan dengan nama database mu

// Paydisini Apikey
global.paydisini_apikey = "APIKEY PAYDISINI";
global.paydisini_nomer = 085773305337;
global.minimalDepoOtomatis = 1000;
global.maximalDepoOtomatis = 1000000;

//MedanPedia 
global.medanpedia_apiID = "API ID"
global.medanpedia_apikey = "APIKEY"

//JF Store Apikey 
global.apikey = "APIKEY"; // register di https://topup.j-f.cloud
